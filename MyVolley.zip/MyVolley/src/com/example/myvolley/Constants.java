package com.example.myvolley;

public class Constants {
	
	private static final String IP="192.168.99.3";
	public static final String WEATHERUPDATA=IP+"WEATHERUPDATA";

}
