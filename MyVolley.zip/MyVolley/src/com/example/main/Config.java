package com.example.main;

public class Config {

	public static final boolean DEVELOPER_MODE = false;
}
